
Old Maps Text Detection - v1 2022-06-16 4:45pm
==============================

This dataset was exported via roboflow.ai on June 16, 2022 at 2:47 PM GMT

It includes 82 images.
Letters are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


